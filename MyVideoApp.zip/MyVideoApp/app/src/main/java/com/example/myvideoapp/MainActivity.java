package com.example.myvideoapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.StrictMode;
import android.util.Log;
import android.webkit.MimeTypeMap;

import java.io.File;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "Sachin";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        StrictMode.VmPolicy.Builder builder = new StrictMode.VmPolicy.Builder();
        StrictMode.setVmPolicy(builder.build());
        //Uri uri = Uri.parse("android.content://com.example.myvideoapp/raw/hasil_movie_scene_1");
        String fileImagePath = "android.resource://" + getPackageName() + "/" + R.raw.hasil_movie_scene_1;
        Uri uri = FileProvider.getUriForFile(MainActivity.this, BuildConfig.APPLICATION_ID + ".provider", new File(fileImagePath));
        //Uri uri = Uri.parse("content://" + getPackageName() + "/" + R.raw.hasil_movie_scene_1);
        //Log.d(TAG,uri.getUserInfo().toString());
        Intent intent = new Intent();
        intent.setAction(android.content.Intent.ACTION_VIEW);
        File file = new File(uri.getPath());

        MimeTypeMap mime = MimeTypeMap.getSingleton();
        String ext = file.getName().substring(file.getName().indexOf(".") + 1);
        String type = mime.getMimeTypeFromExtension(ext);

        intent.setDataAndType(Uri.fromFile(file), "video/*");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivity(intent);
    }
}
